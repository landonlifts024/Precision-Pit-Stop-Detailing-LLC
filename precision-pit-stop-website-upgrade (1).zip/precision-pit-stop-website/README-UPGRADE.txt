PRECISION PIT STOP DETAILING — WEBSITE UPGRADE

FILES
- index.html: updated website with a looping video hero background and a Reviews section.
- hero-background.mp4: add your own background video here (see below).

VIDEO BACKGROUND
1. Choose a video you own or have permission to use. A short, landscape MP4 works best.
2. Name it exactly: hero-background.mp4
3. Upload it into the same folder as index.html.
4. Keep it reasonably compressed (ideally 5–15 MB or less) so the website loads quickly.
5. The video is muted, loops, and uses a poster image as a fallback. Some mobile devices may still pause autoplay to save data.

CUSTOMER REVIEWS
1. Create/claim your Google Business Profile if you have not already.
2. Copy your Google review link from the Business Profile.
3. Open index.html in a text editor and search for: YOUR_GOOGLE_REVIEW_LINK
4. Replace that placeholder with your real Google review URL (keep the quotation marks).
5. Save and re-upload the updated index.html.

IMPORTANT
A plain static website cannot safely store and publish reviews on its own. This upgrade sends customers to your Google review page, where their reviews can be posted publicly. No customer testimonials have been invented or added.
The current website's contact phone number is still (831) 583-5123; confirm it is correct before publishing.
