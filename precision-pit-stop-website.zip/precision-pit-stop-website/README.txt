PRECISION PIT STOP DETAILING — WEBSITE STARTER

FILES
- index.html: the complete responsive website (CSS and JavaScript are included).

HOW TO PREVIEW
1. Download and unzip the folder.
2. Double-click index.html to open it in your browser.
3. Internet is required for Google Fonts and the remote stock-photo backgrounds.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Go to https://github.com and create/sign in to a free account.
2. Create a new public repository named precision-pit-stop-website.
3. Choose Add file > Upload files, then upload index.html.
4. Commit the upload.
5. Open repository Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose branch main and folder /(root), then Save.
8. Wait a few minutes. GitHub Pages will show your published site URL in Settings > Pages.

IMPORTANT BEFORE PUBLISHING
- The quote form opens a pre-filled SMS to (831) 583-5123; it does not save form submissions on a server. Test this on a device with a messaging app.
- Confirm that the phone number is the best business number to publish.
- Confirm your service area and replace the photo placeholders with your own work photos.
- The website intentionally avoids invented reviews, certifications, guarantees, or fixed detailing prices.
- Stock photos are loaded from Unsplash URLs; swap them for your own photos for a more authentic brand.
- Free GitHub Pages hosting uses a github.io address. A custom domain is optional and usually costs money.
